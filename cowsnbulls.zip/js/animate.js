$(document).ready(function(){

	$('#heading').addClass('animated');
	$('#heading').addClass('fadeInDownBig');
	$('.word').addClass('animated');
	$('.word').addClass('zoomInUp');
});